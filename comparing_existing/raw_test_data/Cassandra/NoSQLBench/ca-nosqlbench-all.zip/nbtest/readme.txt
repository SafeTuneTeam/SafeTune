sudo ./nb run driver=cql workload=cql-tabular tags=phase:schema host=127.0.0.1 port=9042
sudo ./nb run driver=cql workload=cql-tabular tags=phase:rampup host=127.0.0.1 port=9042 waitmillis=10  cycles=100000  --classic-histograms prefix
