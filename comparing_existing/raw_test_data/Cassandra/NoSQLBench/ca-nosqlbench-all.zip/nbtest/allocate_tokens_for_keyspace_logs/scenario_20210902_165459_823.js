scenario.run({
    'driver':   'cql',
    'workload': 'cql-tabular',
    'tags':     'phase:rampup',
    'host':     '127.0.0.1',
    'port':     '9042',
    'cycles':   '100000',
    'threads':  '8'
});
